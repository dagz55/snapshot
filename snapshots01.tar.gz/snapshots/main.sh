#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# Function to create and activate virtual environment
setup_venv() {
    python -m venv snapvenv
    source snapvenv/bin/activate
    pip3 install --upgrade pip
    pip install -r requirements.txt
}

# Function to validate snapshots
validate_snapshots() {
    # Run the Python script
    python validate/validate_snapshot.py
}

# Function to create snapshots
create_snapshots() {
    python create/create_snapshot.py
}

# Function to delete snapshots
delete_snapshots() {
    python delete/delete_snapshot.py    
}

# Setup virtual environment if it doesn't exist
if [ ! -d "snapvenv" ]; then
    setup_venv
else
    source snapvenv/bin/activate
fi

# Main menu loop
while true; do
    echo "Snapshot Management Menu"
    echo "1. Create Snapshots"
    echo "2. Validate Snapshots"
    echo "3. Delete Snapshots"
    echo "4. Exit"
    read -p "Please enter your choice (1-4): " choice

    case $choice in
        1)
            create_snapshots
            ;;
        2)
            validate_snapshots
            ;;
        3)
            delete_snapshots
            ;;
        4)
            echo "Exiting..."
            deactivate
            exit 0
            ;;
        *)
            echo "Invalid option. Please try again."
            ;;
    esac

    echo
done
