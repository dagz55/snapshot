import subprocess
import datetime
import json
from rich.console import Console
from rich.table import Table
from rich.progress import Progress
from rich.prompt import Confirm
import time

console = Console()

def run_az_command(command):
   result = subprocess.run(command, shell=True, capture_output=True, text=True)
   if result.returncode != 0:
       console.print(f"[bold red]Error running command:[/bold red] {command}")
       console.print(f"[red]{result.stderr}[/red]")
       return None
   return result.stdout.strip()

def validate_snapshots(snapshot_list_file):
   start_time = time.time()
   console.print("[bold cyan]Starting snapshot validation...[/bold cyan]")

   with open(snapshot_list_file, "r") as file:
       snapshot_ids = file.read().splitlines()

   total_snapshots = len(snapshot_ids)
   validated_snapshots = []

   with Progress() as progress:
       task = progress.add_task("[cyan]Validating snapshots...", total=total_snapshots)

       for snapshot_id in snapshot_ids:
           snapshot_info = {}
           snapshot_info['id'] = snapshot_id

           # Get snapshot details
           details = run_az_command(f"az snapshot show --ids {snapshot_id} --query '{{name:name, resourceGroup:resourceGroup, timeCreated:timeCreated, diskSizeGb:diskSizeGb, provisioningState:provisioningState}}' -o json")

           if details:
               details = json.loads(details)
               snapshot_info['exists'] = True
               snapshot_info['name'] = details['name']
               snapshot_info['resource_group'] = details['resourceGroup']
               snapshot_info['time_created'] = details['timeCreated']
               snapshot_info['size_gb'] = details['diskSizeGb']
               snapshot_info['state'] = details['provisioningState']
           else:
               snapshot_info['exists'] = False

           validated_snapshots.append(snapshot_info)
           progress.update(task, advance=1)

   # Calculate runtime
   end_time = time.time()
   runtime = end_time - start_time

   # Create summary table
   table = Table(title="Snapshot Validation Summary")
   table.add_column("Snapshot ID", style="cyan")
   table.add_column("Name", style="cyan")
   table.add_column("Exists", style="green")
   table.add_column("Resource Group", style="magenta")
   table.add_column("Time Created", style="yellow")
   table.add_column("Size (GB)", style="blue")
   table.add_column("State", style="red")

   for snapshot in validated_snapshots:
       table.add_row(
           snapshot['id'],
           snapshot.get('name', 'N/A'),
           "✅" if snapshot['exists'] else "❌",
           snapshot.get('resource_group', 'N/A'),
           snapshot.get('time_created', 'N/A'),
           str(snapshot.get('size_gb', 'N/A')),
           snapshot.get('state', 'N/A')
       )

   console.print(table)

   # Print summary
   console.print(f"\n[bold green]Validation complete![/bold green]")
   console.print(f"Total snapshots processed: {total_snapshots}")
   console.print(f"Existing snapshots: {sum(1 for s in validated_snapshots if s['exists'])}")
   console.print(f"Missing snapshots: {sum(1 for s in validated_snapshots if not s['exists'])}")
   console.print(f"Runtime: {runtime:.2f} seconds")

   # Ask user if they want to save the log
   if Confirm.ask("Do you want to save the validation results to a log file?"):
       timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
       log_file = f"snapshot_validation_log_{timestamp}.txt"
       with open(log_file, "w") as f:
           f.write("Snapshot Validation Results\n")
           f.write("===========================\n\n")
           for snapshot in validated_snapshots:
               f.write(f"Snapshot ID: {snapshot['id']}\n")
               f.write(f"Exists: {'Yes' if snapshot['exists'] else 'No'}\n")
               if snapshot['exists']:
                   f.write(f"Name: {snapshot['name']}\n")
                   f.write(f"Resource Group: {snapshot['resource_group']}\n")
                   f.write(f"Time Created: {snapshot['time_created']}\n")
                   f.write(f"Size (GB): {snapshot['size_gb']}\n")
                   f.write(f"State: {snapshot['state']}\n")
               f.write("\n")
           f.write(f"\nTotal snapshots processed: {total_snapshots}\n")
           f.write(f"Existing snapshots: {sum(1 for s in validated_snapshots if s['exists'])}\n")
           f.write(f"Missing snapshots: {sum(1 for s in validated_snapshots if not s['exists'])}\n")        
           f.write(f"Runtime: {runtime:.2f} seconds\n")
       console.print(f"[bold green]Log file saved:[/bold green] {log_file}")

if __name__ == "__main__":
   snapshot_list_file = "validate/snapshot_list.txt"
   validate_snapshots(snapshot_list_file)

